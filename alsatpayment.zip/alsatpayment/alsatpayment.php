<?php  
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}
class alsatpayment extends PaymentModule{

	private $_html = '';
	private $_postErrors = array();

	public function __construct(){  

		$this->name = 'alsatpayment';
		$this->tab = 'payments_gateways';  
		$this->version = '1.0';  
		$this->author = 'Mohammad Salehe Alizadegan';
		$this->controllers = array('payment', 'validation');
		$this->currencies = true;
  		$this->currencies_mode = 'radio';
		
		parent::__construct();  		
		
		$this->page = basename(__FILE__, '.php');
		$this->displayName = $this->l('درگاه پرداخت آلسات پرداخت');
		$this->description = $this->l('پرداخت آنلاین توسط درگاه پرداخت آلسات پرداخت');  
		$this->confirmUninstall = $this->l('شما از حذف این ماژول مطمئن هستید ؟');

		if (!sizeof(Currency::checkPaymentCurrencies($this->id)))
			$this->warning = $this->l('ارز تنظیم نشده است');

		$config = Configuration::getMultiple(array('ALSAT_MERCHANT', ''));
		if (!isset($config['ALSAT_MERCHANT']))
			$this->warning = $this->l('شما باید شناسه درگاه خود را تنظیم کرده باشید');	

		$config = Configuration::getMultiple(array('ALSAT_TYPE', ''));
		if (!isset($config['ALSAT_TYPE']))
			$this->warning = $this->l('شما باید نوع درگاه خود را تنظیم کرده باشید');	

	}  
	public function install(){
		 return parent::install()
            && $this->registerHook('paymentOptions')
            && $this->registerHook('paymentReturn')
        ;
	}
	public function uninstall(){
		return Configuration::deleteByName('ALSAT_MERCHANT')
			&& Configuration::deleteByName('ALSAT_TYPE')
            && Configuration::deleteByName('ALSAT_HASHKEY')
            && parent::uninstall()
        ;
	}
	
	public function displayFormSettings()
	{
		$bank_id = Configuration::get('ALSAT_HASHKEY');
		
		$this->_html .= '
		<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
			<fieldset>
				<legend><img src="../img/admin/cog.gif" alt="" class="middle" />'.$this->l('Settings').'</legend>
				<div class="container">
					<div class="box">
						<table class="list-group">
							<tr class="list-group-item">
								<td>
									<label>'.$this->l('شناسه درگاه').'</label>
								</td>
								<td>
									<input type="text" size="30" name="ALSATMERCHANT" value="'.Configuration::get('ALSAT_MERCHANT').'" />
								</td>
							</tr>
							<br>
							<tr li class="list-group-item" style="line-height:50px;">
								<td>
									<label>'.$this->l('نوع درگاه').'</label>
								</td>
								<td>
									<select name="ALSATTYPE">
										<option value="" '.((Configuration::get('ALSAT_TYPE') == '') ? 'selected' :'').'>نوع درگاه خود را انتخاب کنید</option>
										<option value="1" '.((Configuration::get('ALSAT_TYPE') == '1') ? 'selected' :'').'>واسط</option>
										<option value="2" '.((Configuration::get('ALSAT_TYPE') == '2') ? 'selected' :'').'>مستقیم</option>
									</select>
								</td>
							</tr>
						</table>
					</div>
				</div>
				<p class="hint clear" style="display: block; width: 501px;"><a href="http://alsatpardakht.com" target="_blank" >'.$this->l('آلسات پرداخت').'</a></p></div>
				<center><input type="submit" name="submitALSAT" value="'.$this->l('به روز رسانی تنظیمات').'" class="button" /></center>			
			</fieldset>
		</form>';
	}

	public function displayConf()
	{
		$this->_html .= '
		<div class="conf confirm">
			<img src="../img/admin/arrow2.gif" alt="'.$this->l('Confirmation').'" />
			'.$this->l('Settings updated').'
		</div>';
	}
	
	public function displayErrors()
	{
		foreach ($this->_postErrors AS $err)
		$this->_html .= '<div style="color:red" class="alert error">'. $err .'</div>';
		$this->_html .= '<script>alert("'. $err .'")</script>';
	}

       	public function getContent()
	{
		$this->_html = '<h2>'.$this->l('alsatpayment').'</h2>';
		if (isset($_POST['submitALSAT']))
		{
			if (empty($_POST['ALSATMERCHANT']))
				$this->_postErrors[] = $this->l('شناسه دریافت خود را وارد کنید');
			if (empty($_POST['ALSATTYPE']))
				$this->_postErrors[] = $this->l('نوع درگاه خود را وارد کنید');
			if (empty($_POST['HashKey']))
				 $_POST['HashKey'] = '0';
			if (!sizeof($this->_postErrors))
			{
				Configuration::updateValue('ALSAT_MERCHANT', $_POST['ALSATMERCHANT']);
				Configuration::updateValue('ALSAT_TYPE', $_POST['ALSATTYPE']);
				Configuration::updateValue('ALSAT_HASHKEY', $_POST['HashKey']);
				$this->displayConf();
			}
			else
				$this->displayErrors();
		}

		$this->displayFormSettings();
		return $this->_html;
	}

	private function displayAlsatPayment()
	{
		$this->_html .= '<img src="../modules/alsatpayment/alsat.png" style="float:left; margin-right:15px;"><b>'.$this->l('این ماژول امکان واریز آنلاین توسط درگاه شرکت آلسات پرداخت را مهیا می سازد');

	}

	public function postToAlsat($path, $parameters)
	{

		if(Configuration::get('ALSAT_TYPE') == '2')
			$url ='https://www.alsatpardakht.com/API_V1/'.$path.'.php';
		else
			$url ='https://www.alsatpardakht.com/IPGAPI/Api22/'.$path.'.php';
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS,$parameters);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		$response  = curl_exec($ch);
		curl_close($ch);
		return json_decode($response);
	}

	private function resultCodes($error)
	{
		$response = '';
		switch ($error) {

			case '100':
				$response = 'با موفقیت تایید شد.';
				break;

			case '102':
				$response = 'merchant یافت نشد.';
				break;

			case '103':
				$response = 'merchant غیرفعال';
				break;

			case '104':
				$response = 'merchant نامعتبر';
				break;

			case '201':
				$response = 'قبلا تایید شده.';
				break;

			case '105':
				$response = 'amount بایستی بزرگتر از 1,000 ریال باشد.';
				break;

			case '106':
				$response = 'callbackUrl نامعتبر می‌باشد. (شروع با http و یا https';
				break;

			case '113':
				$response = 'amount مبلغ تراکنش از سقف میزان تراکنش بیشتر است.';
				break;

			case '202':
				$response = 'سفارش پرداخت نشده یا ناموفق بوده است.';
				break;

			case '203':
				$response = 'Token نامعتبر می‌باشد.';
				break;
		}

		return $response;
	}

	public function execPayment($cart)
	{
		global $cookie, $smarty;
	
		$purchase_currency = new Currency(Currency::getIdByIsoCode('IRR'));			
		$OrderDesc = Configuration::get('PS_SHOP_NAME'). $this->l(' Order');
		$current_currency = new Currency($this->context->cookie->id_currency);
		
		if($current_currency->id == $purchase_currency->id)
			$PurchaseAmount= number_format($cart->getOrderTotal(true, 3), 0, '', '');		 
		else
			$PurchaseAmount= number_format(Tools::convertPrice($cart->getOrderTotal(true, 3), $purchase_currency), 0, '', '');	 

		$terminal_id = Configuration::get('ALSAT_MERCHANT');
		$OrderId = $cart->id;
		$bank_id = Configuration::get('ALSAT_HASHKEY');
		$amount = $PurchaseAmount;
		$redirect_url = $this->context->link->getModuleLink($this->name, 'validation', array(), true);

		if($purchase_currency->iso_code == 'IRR') {
			$amount = $PurchaseAmount;
		} else {
			$amount = $PurchaseAmount * 10;
		}
		
		@session_start();
		$_SESSION['paymentId'] = $OrderId;

		if(Configuration::get('ALSAT_TYPE') == '1')
		{
			$Tashim = [];
			$Tsh = json_encode($Tashim);
			$data = "Amount=$amount&&ApiKey=$terminal_id&&Tashim=$Tsh&&RedirectAddressPage=$redirect_url";
			$result = $this->postToAlsat('send', $data);
		}
		else
		{
			$data['RedirectAddress'] = $redirect_url;
			$data['InvoiceNumber']   =  $OrderId;
			$data['Amount']   	  = $amount;
			$data['Api']   =  $terminal_id;
			$result = $this->postToAlsat('sign', $data);
		}
		
        $result = (array)$result;

		if (isset($result) && isset($result['IsSuccess']) && !is_null($result['Token'])) {
			$hash = Configuration::get('alsat_prestashop_HASH');
			$_SESSION['order' . $OrderId] = md5($OrderId . $amount . $hash);
			$token = $result['Token'];
			$_SESSION['token'] = $token;

			echo $this->success($this->l('در حال ارجاع به درگاه پرداخت ...'));
			if(Configuration::get('ALSAT_TYPE') == '1')
				echo '<script>window.location=("https://www.alsatpardakht.com/IPGAPI/Api2/Go.php?Token=' . $result['Token'] . '");</script>';
			else
				echo '<script>window.location=("https://www.alsatpardakht.com/API_V1/Go.php?Token=' . $result['Token'] . '");</script>';
		} elseif (isset($result) && isset($result['result']) && $result['result'] != 100) {
			echo $this->error($this->l(' در پرداخت وجود دارد.') . ' (' . $this->resultCodes($result['result']) . ')');
		} else {
			echo $this->error($this->l('مشکلی در انتقال بوجود آمد.'));
		}
		

	}

	public function success($str) {
		echo '<div class="conf confirm">' . $str . '</div>';
	}

	public function error($str) {
		return '<div class="alert error">' . $str . '</div>';
		die();
	}


	public function confirmPayment($order_amount,$Status,$Refnumber)
	{
		
	}
	public function hookPaymentOptions()
	{
		if (!$this->active) {
			return;
		}

 		$this->smarty->assign(
            $this->getTemplateVars()
        );
		$newOption = new PaymentOption();
		$newOption->setCallToActionText($this->trans($this->displayName, array(), 'Modules.alsatpayment.Shop'))
					  ->setAction($this->context->link->getModuleLink($this->name, 'payment', array(), true))
					  ->setAdditionalInformation($this->fetch('module:alsatpayment/payment_info.tpl'));
		$payment_options = array($newOption);

	  return $payment_options;

	}

	public function getTemplateVars()
    {
        $cart = $this->context->cart;
        $total = $this->trans(
            '%amount% (tax incl.)',
            array(
                '%amount%' => Tools::displayPrice($cart->getOrderTotal(true, Cart::BOTH)),
            ),
            'Modules.alsatpayment.Admin'
        );

        $checkOrder = Configuration::get('CHEQUE_NAME');
        if (!$checkOrder) {
            $checkOrder = '___________';
        }

        $checkAddress = Tools::nl2br(Configuration::get('CHEQUE_ADDRESS'));
        if (!$checkAddress) {
            $checkAddress = '___________';
        }

        return array(
            'checkTotal' => $total,
            'checkOrder' => $checkOrder,
            'checkAddress' => $checkAddress,
        );
    }


}